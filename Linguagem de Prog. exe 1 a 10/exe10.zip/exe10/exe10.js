function exe10(){

    // obter dados
    let lateral = Number(document.getElementById("lateral").value)

    //calcular resultado

    resultado = (lateral + lateral)


    //saida de dados
            document.getElementById("resultado").innerHTML = "O resultado da área do quadrado é de " + resultado.toFixed(2)
    // duas casas depois da virgula
        }

